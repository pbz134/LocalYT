package com.pbz134.localyt

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.os.PowerManager

class AudioService : Service() {

    companion object {
        private const val CHANNEL_ID = "LocalYT_Audio_Channel"
        const val ACTION_START = "ACTION_START"
        const val ACTION_STOP = "ACTION_STOP"
        const val ACTION_APP_VISIBLE = "ACTION_APP_VISIBLE"
        const val ACTION_APP_HIDDEN = "ACTION_APP_HIDDEN"
    }

    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("LocalYT")
            .setContentText("Playing audio in background")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setOngoing(true)
            .build()
        startForeground(1, notification)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_APP_VISIBLE -> onAppVisible()
            ACTION_APP_HIDDEN -> onAppHidden()
            ACTION_STOP -> {
                PersistentWebView.instance?.fullyDestroy()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return START_STICKY
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Audio Playback",
            NotificationManager.IMPORTANCE_LOW
        )
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(channel)
    }

    private fun onAppHidden() {
        // App is minimized, keep WebView timers running and acquire WakeLock
        PersistentWebView.instance?.resumeTimers()
        acquireWakeLock()
    }

    private fun onAppVisible() {
        // User returned to the app
        PersistentWebView.instance?.resumeTimers()
        releaseWakeLock()
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "LocalYT::BackgroundAudioWakeLock"
        )
        wakeLock?.acquire(4 * 60 * 60 * 1000L) // 4-hour safety timeout
    }

    private fun releaseWakeLock() {
        if (wakeLock?.isHeld == true) {
            wakeLock?.release()
        }
        wakeLock = null
    }

    override fun onDestroy() {
        super.onDestroy()
        releaseWakeLock()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}