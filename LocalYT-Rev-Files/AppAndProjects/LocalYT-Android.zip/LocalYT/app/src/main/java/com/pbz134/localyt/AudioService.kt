package com.pbz134.localyt

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.IBinder

class AudioService : Service() {

    companion object {
        private const val CHANNEL_ID = "LocalYT_Audio_Channel"
        const val ACTION_START = "ACTION_START"
        const val ACTION_STOP = "ACTION_STOP"
        const val ACTION_APP_VISIBLE = "ACTION_APP_VISIBLE"
        const val ACTION_APP_HIDDEN = "ACTION_APP_HIDDEN"
    }

    override fun onCreate() {
        super.onCreate()
        // MUST call startForeground immediately to prevent Android from killing the service
        createNotificationChannel()
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("LocalYT")
            .setContentText("Playing audio in background")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setOngoing(true)
            .build()
        startForeground(1, notification)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_APP_VISIBLE -> onAppVisible()
            ACTION_APP_HIDDEN -> onAppHidden()
            ACTION_STOP -> {
                PersistentWebView.instance?.fullyDestroy()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return START_STICKY
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Audio Playback",
            NotificationManager.IMPORTANCE_LOW // Low importance so it doesn't make a sound
        )
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(channel)
    }

    private fun onAppHidden() {
        // When the app is minimized, we do NOTHING to the WebView.
        // By not calling onPause(), the WebView continues playing audio!
    }

    private fun onAppVisible() {
        // When the user returns to the app, resume the WebView timers 
        // in case the system paused them while in the background.
        PersistentWebView.instance?.resumeTimers()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}