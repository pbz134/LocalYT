package com.pbz134.localyt

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ProgressBar
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen

class MainActivity : AppCompatActivity() {
    private lateinit var webView: PersistentWebView
    private lateinit var progressBar: ProgressBar
    private val handler = Handler(Looper.getMainLooper())
    private var isUrlDialogShowing = false

    // Custom WebChromeClient to handle HTML5 fullscreen
    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null

    // Splash Screen flag to keep it visible while WebView loads
    private var keepSplashOnScreen = true

    companion object {
        private const val PREFS_NAME = "LocalYTPrefs"
        private const val KEY_SERVER_URL = "server_url"
        private const val DEFAULT_URL = "https://localyt.net"
        private const val NOTIFICATION_PERMISSION_CODE = 101
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {

        // INSTALL THE SPLASH SCREEN (Must be called before setContentView)
        val splashScreen = installSplashScreen()

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Tell the splash screen to stay visible until our WebView loads
        splashScreen.setKeepOnScreenCondition { keepSplashOnScreen }

        webView = findViewById(R.id.webView)
        progressBar = findViewById(R.id.progressBar)

        requestNotificationPermission()

        // Start the background audio service
        val serviceIntent = Intent(this, AudioService::class.java).apply {
            action = AudioService.ACTION_START
        }
        startForegroundService(serviceIntent)

        webView.addJavascriptInterface(this, "Android")

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)

                // THE PAGE HAS LOADED: Let the splash screen fade away!
                keepSplashOnScreen = false

                // INJECT: Trick the webpage into thinking it's always visible so it doesn't pause the video
                injectVisibilityOverride(view)
                view?.evaluateJavascript("Android.checkPageContent(document.body.innerText);", null)
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                super.onReceivedError(view, request, error)
                if (request?.isForMainFrame == true) {
                    // If there's an error, we still need to dismiss the splash screen
                    keepSplashOnScreen = false
                    showUrlDialog()
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                if (customView != null) {
                    onHideCustomView()
                }
                customView = view
                customViewCallback = callback

                webView.visibility = View.GONE
                val rootView = findViewById<FrameLayout>(android.R.id.content)
                rootView.addView(view, FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                ))

                hideSystemUI()
            }

            override fun onHideCustomView() {
                if (customView == null) return

                webView.visibility = View.VISIBLE
                val rootView = findViewById<FrameLayout>(android.R.id.content)
                rootView.removeView(customView)
                customView = null
                customViewCallback?.onCustomViewHidden()
                customViewCallback = null

                showSystemUI()
            }
        }

        val webSettings = webView.settings
        webSettings.javaScriptEnabled = true
        webSettings.domStorageEnabled = true
        webSettings.mediaPlaybackRequiresUserGesture = false
        webSettings.useWideViewPort = true

        val savedUrl = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getString(KEY_SERVER_URL, DEFAULT_URL)!!
        webView.loadUrl(savedUrl)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (customView != null) {
                    (webView.webChromeClient as? WebChromeClient)?.onHideCustomView()
                } else if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    finish()
                }
            }
        })
    }

    private fun injectVisibilityOverride(view: WebView?) {
        val js = """
            (function() {
                // 1. Override the API so the page always thinks it's visible
                Object.defineProperty(document, 'visibilityState', { value: 'visible', writable: true });
                Object.defineProperty(document, 'hidden', { value: false, writable: true });
                
                // 2. Intercept the video.pause() command to know if the USER paused it
                const origPause = HTMLVideoElement.prototype.pause;
                HTMLVideoElement.prototype.pause = function() {
                    this.dataset.manuallyPaused = 'true'; // Flag it as user-paused
                    origPause.call(this);
                };
                
                // 3. Intercept the video.play() command to remove the flag
                const origPlay = HTMLVideoElement.prototype.play;
                HTMLVideoElement.prototype.play = function() {
                    delete this.dataset.manuallyPaused;
                    return origPlay.call(this);
                };
                
                // 4. Listen for the 'pause' event on any video. If it wasn't manually paused, force it to resume!
                document.addEventListener('pause', function(e) {
                    if (e.target.tagName === 'VIDEO' && !e.target.dataset.manuallyPaused) {
                        // The system tried to pause it. Force it back to play!
                        e.target.play().catch(function(){});
                    }
                }, true); // 'true' means capture phase, catches it before the player sees it
            })();
        """
        view?.evaluateJavascript(js, null)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)

        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            webView.evaluateJavascript("document.querySelector('.lyt_btn_fullscreen')?.click();", null)
        } else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT) {
            if (customView != null) {
                (webView.webChromeClient as? WebChromeClient)?.onHideCustomView()
            }
        }
    }

    private fun hideSystemUI() {
        window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        or View.SYSTEM_UI_FLAG_FULLSCREEN
                )
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
    }

    private fun showSystemUI() {
        window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                )
        window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), NOTIFICATION_PERMISSION_CODE)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        val intent = Intent(this, AudioService::class.java).apply { action = AudioService.ACTION_APP_VISIBLE }
        startService(intent)

        webView.onResume()
        webView.resumeTimers()
        handler.postDelayed(showDialogRunnable, 10000)
    }

    override fun onPause() {
        super.onPause()
        val intent = Intent(this, AudioService::class.java).apply { action = AudioService.ACTION_APP_HIDDEN }
        startService(intent)

        // DO NOT call webView.onPause() here!
        webView.resumeTimers()
        handler.removeCallbacks(showDialogRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing) {
            val intent = Intent(this, AudioService::class.java).apply { action = AudioService.ACTION_STOP }
            startService(intent)
        }
    }

    private val showDialogRunnable = Runnable {
        if (!isUrlDialogShowing && progressBar.visibility == FrameLayout.VISIBLE) {
            showUrlDialog()
        }
    }

    @JavascriptInterface
    fun checkPageContent(pageText: String) {
        if (pageText.trim().contains("502 Bad Gateway", ignoreCase = true)) {
            handler.post {
                if (!isUrlDialogShowing) {
                    showUrlDialog()
                }
            }
        } else {
            handler.removeCallbacks(showDialogRunnable)
            progressBar.visibility = FrameLayout.GONE
        }
    }

    @JavascriptInterface
    fun executeJS(jsCode: String) {
        handler.post {
            if (webView != null) {
                webView.evaluateJavascript(jsCode, null)
            }
        }
    }

    private fun showUrlDialog() {
        if (isUrlDialogShowing) return
        isUrlDialogShowing = true
        handler.removeCallbacks(showDialogRunnable)

        val editText = EditText(this).apply {
            hint = "https://your-new-link.trycloudflare.com"
            val currentUrl = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                .getString(KEY_SERVER_URL, DEFAULT_URL)
            setText(currentUrl)
            setSelection(text.length)
        }

        AlertDialog.Builder(this)
            .setTitle("Connect to LocalYT")
            .setMessage("The current URL is unreachable or returned a 502 error. Enter the URL to connect to your LocalYT server:")
            .setView(editText)
            .setPositiveButton("Connect") { _, _ ->
                var newUrl = editText.text.toString().trim()

                if (newUrl.isNotEmpty() && !newUrl.startsWith("http://") && !newUrl.startsWith("https://")) {
                    newUrl = "https://$newUrl"
                }

                if (newUrl.isNotEmpty()) {
                    getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                        .edit()
                        .putString(KEY_SERVER_URL, newUrl)
                        .apply()

                    isUrlDialogShowing = false
                    progressBar.visibility = FrameLayout.VISIBLE
                    webView.loadUrl(newUrl)
                } else {
                    isUrlDialogShowing = false
                    showUrlDialog()
                }
            }
            .setNegativeButton("Cancel") { dialog, _ ->
                isUrlDialogShowing = false
                dialog.cancel()
            }
            .setCancelable(false)
            .show()
    }
}