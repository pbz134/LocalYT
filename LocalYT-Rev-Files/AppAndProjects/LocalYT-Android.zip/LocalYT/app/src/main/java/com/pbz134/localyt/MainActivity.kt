package com.pbz134.localyt

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ProgressBar
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var webView: PersistentWebView
    private lateinit var progressBar: ProgressBar
    private val handler = Handler(Looper.getMainLooper())
    private var isUrlDialogShowing = false

    companion object {
        private const val PREFS_NAME = "LocalYTPrefs"
        private const val KEY_SERVER_URL = "server_url"
        private const val DEFAULT_URL = "https://localyt.net"
        private const val NOTIFICATION_PERMISSION_CODE = 101
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        progressBar = findViewById(R.id.progressBar)

        // Request notification permission for Android 13+
        requestNotificationPermission()

        // Start the background audio service
        val serviceIntent = Intent(this, AudioService::class.java).apply {
            action = AudioService.ACTION_START
        }
        startForegroundService(serviceIntent)

        webView.addJavascriptInterface(this, "Android")

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                view?.evaluateJavascript("Android.checkPageContent(document.body.innerText);", null)
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                super.onReceivedError(view, request, error)
                if (request?.isForMainFrame == true) {
                    showUrlDialog()
                }
            }
        }

        val webSettings = webView.settings
        webSettings.javaScriptEnabled = true
        webSettings.domStorageEnabled = true
        webSettings.mediaPlaybackRequiresUserGesture = false
        webSettings.useWideViewPort = true

        val savedUrl = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getString(KEY_SERVER_URL, DEFAULT_URL)!!
        webView.loadUrl(savedUrl)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    finish()
                }
            }
        })
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), NOTIFICATION_PERMISSION_CODE)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Tell the service the app is visible
        val intent = Intent(this, AudioService::class.java).apply { action = AudioService.ACTION_APP_VISIBLE }
        startService(intent)
        
        webView.onResume()
        webView.resumeTimers()

        handler.postDelayed(showDialogRunnable, 10000)
    }

    override fun onPause() {
        super.onPause()
        // Tell the service the app is hidden (minimized)
        val intent = Intent(this, AudioService::class.java).apply { action = AudioService.ACTION_APP_HIDDEN }
        startService(intent)

        // VERY IMPORTANT: DO NOT call webView.onPause() or webView.pauseTimers() here!
        // If you do, Android will suspend the WebView and audio will instantly stop.
        
        handler.removeCallbacks(showDialogRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        // Stop the service if the user explicitly closes the app from the recent apps menu
        if (isFinishing) {
            val intent = Intent(this, AudioService::class.java).apply { action = AudioService.ACTION_STOP }
            startService(intent)
        }
    }

    private val showDialogRunnable = Runnable {
        if (!isUrlDialogShowing && progressBar.visibility == FrameLayout.VISIBLE) {
            showUrlDialog()
        }
    }

    @JavascriptInterface
    fun checkPageContent(pageText: String) {
        if (pageText.trim().contains("502 Bad Gateway", ignoreCase = true)) {
            handler.post {
                if (!isUrlDialogShowing) {
                    showUrlDialog()
                }
            }
        } else {
            handler.removeCallbacks(showDialogRunnable)
            progressBar.visibility = FrameLayout.GONE
        }
    }

    private fun showUrlDialog() {
        if (isUrlDialogShowing) return
        isUrlDialogShowing = true
        handler.removeCallbacks(showDialogRunnable)

        val editText = EditText(this).apply {
            hint = "https://your-new-link.trycloudflare.com"
            val currentUrl = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                .getString(KEY_SERVER_URL, DEFAULT_URL)
            setText(currentUrl)
            setSelection(text.length)
        }

        AlertDialog.Builder(this)
            .setTitle("Connect to LocalYT")
            .setMessage("The current URL is unreachable or returned a 502 error. Enter the URL to connect to your LocalYT server:")
            .setView(editText)
            .setPositiveButton("Connect") { _, _ ->
                var newUrl = editText.text.toString().trim()

                if (newUrl.isNotEmpty() && !newUrl.startsWith("http://") && !newUrl.startsWith("https://")) {
                    newUrl = "https://$newUrl"
                }

                if (newUrl.isNotEmpty()) {
                    getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                        .edit()
                        .putString(KEY_SERVER_URL, newUrl)
                        .apply()

                    isUrlDialogShowing = false
                    progressBar.visibility = FrameLayout.VISIBLE
                    webView.loadUrl(newUrl)
                } else {
                    isUrlDialogShowing = false
                    showUrlDialog()
                }
            }
            .setNegativeButton("Cancel") { dialog, _ ->
                isUrlDialogShowing = false
                dialog.cancel()
            }
            .setCancelable(false)
            .show()
    }
}