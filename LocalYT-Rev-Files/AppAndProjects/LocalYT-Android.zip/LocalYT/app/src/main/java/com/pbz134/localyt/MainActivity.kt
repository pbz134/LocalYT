package com.pbz134.localyt

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ProgressBar
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private lateinit var progressBar: ProgressBar
    private val handler = Handler(Looper.getMainLooper())
    private var isUrlDialogShowing = false

    companion object {
        private const val PREFS_NAME = "LocalYTPrefs"
        private const val KEY_SERVER_URL = "server_url"
        private const val DEFAULT_URL = "https://localyt.net"
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        progressBar = findViewById(R.id.progressBar)

        // Inject a JavaScript interface to read the page content from the WebView
        webView.addJavascriptInterface(this, "Android")

        // Force links to open in the app instead of an external browser
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                // Once the page finishes loading, inject JS to read the body text
                // and send it back to checkPageContent()
                view?.evaluateJavascript("Android.checkPageContent(document.body.innerText);", null)
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                super.onReceivedError(view, request, error)
                if (request?.isForMainFrame == true) {
                    // A hard network error occurred (e.g. completely offline)
                    showUrlDialog()
                }
            }
        }

        // WebChromeClient is important for smoother HTML5 video playback
        webView.webChromeClient = WebChromeClient()

        // Enable JavaScript and DOM Storage
        val webSettings = webView.settings
        webSettings.javaScriptEnabled = true
        webSettings.domStorageEnabled = true
        webSettings.mediaPlaybackRequiresUserGesture = false

        // Allow the WebView to read safe-area-inset variables for the status bar
        webSettings.useWideViewPort = true

        // Load saved URL, or default if none exists
        val savedUrl = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getString(KEY_SERVER_URL, DEFAULT_URL)!!
        webView.loadUrl(savedUrl)

        // Handle the hardware back button for web navigation
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack() // Go to previous web page
                } else {
                    finish() // Close the app if no history is left
                }
            }
        })
    }

    override fun onResume() {
        super.onResume()
        // Start a 10-second timer. If the page hasn't loaded by then, show the popup.
        handler.postDelayed(showDialogRunnable, 10000)
    }

    override fun onPause() {
        super.onPause()
        // Cancel the timer if the user minimizes the app
        handler.removeCallbacks(showDialogRunnable)
    }

    private val showDialogRunnable = Runnable {
        if (!isUrlDialogShowing && progressBar.visibility == FrameLayout.VISIBLE) {
            showUrlDialog()
        }
    }

    // This method is called from the JavaScript injected in onPageFinished
    @JavascriptInterface
    fun checkPageContent(pageText: String) {
        // Check if Cloudflare returned its plain-text 502 page
        // Using contains and trimming whitespace to be safe against minor formatting changes
        if (pageText.trim().contains("502 Bad Gateway", ignoreCase = true)) {
            handler.post {
                if (!isUrlDialogShowing) {
                    showUrlDialog()
                }
            }
        } else {
            // The page loaded and it's NOT the Cloudflare error page. We are successfully connected!
            handler.removeCallbacks(showDialogRunnable)
            progressBar.visibility = FrameLayout.GONE
        }
    }

    private fun showUrlDialog() {
        if (isUrlDialogShowing) return
        isUrlDialogShowing = true
        handler.removeCallbacks(showDialogRunnable)

        val editText = EditText(this).apply {
            hint = "https://your-new-link.trycloudflare.com"
            val currentUrl = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                .getString(KEY_SERVER_URL, DEFAULT_URL)
            setText(currentUrl)
            setSelection(text.length)
        }

        AlertDialog.Builder(this)
            .setTitle("Connect to LocalYT")
            .setMessage("The current URL is unreachable or returned a 502 error. Enter the URL to connect to your LocalYT server:")
            .setView(editText)
            .setPositiveButton("Connect") { _, _ ->
                var newUrl = editText.text.toString().trim()

                if (newUrl.isNotEmpty() && !newUrl.startsWith("http://") && !newUrl.startsWith("https://")) {
                    newUrl = "https://$newUrl"
                }

                if (newUrl.isNotEmpty()) {
                    getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                        .edit()
                        .putString(KEY_SERVER_URL, newUrl)
                        .apply()

                    isUrlDialogShowing = false
                    progressBar.visibility = FrameLayout.VISIBLE
                    webView.loadUrl(newUrl)
                } else {
                    isUrlDialogShowing = false
                    showUrlDialog() // Re-show if they left it blank
                }
            }
            .setNegativeButton("Cancel") { dialog, _ ->
                isUrlDialogShowing = false
                dialog.cancel()
            }
            .setCancelable(false)
            .show()
    }
}