package com.pbz134.localyt

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ProgressBar
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var webView: PersistentWebView
    private lateinit var progressBar: ProgressBar
    private val handler = Handler(Looper.getMainLooper())
    private var isUrlDialogShowing = false

    // Custom WebChromeClient to handle HTML5 fullscreen
    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null

    companion object {
        private const val PREFS_NAME = "LocalYTPrefs"
        private const val KEY_SERVER_URL = "server_url"
        private const val DEFAULT_URL = "https://localyt.net"
        private const val NOTIFICATION_PERMISSION_CODE = 101
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        progressBar = findViewById(R.id.progressBar)

        requestNotificationPermission()

        // Start the background audio service
        val serviceIntent = Intent(this, AudioService::class.java).apply {
            action = AudioService.ACTION_START
        }
        startForegroundService(serviceIntent)

        webView.addJavascriptInterface(this, "Android")

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                view?.evaluateJavascript("Android.checkPageContent(document.body.innerText);", null)
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                super.onReceivedError(view, request, error)
                if (request?.isForMainFrame == true) {
                    showUrlDialog()
                }
            }
        }

        // WebChromeClient intercepts the JS fullscreen request to hide system bars
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                if (customView != null) {
                    onHideCustomView()
                }
                customView = view
                customViewCallback = callback

                webView.visibility = View.GONE
                val rootView = findViewById<FrameLayout>(android.R.id.content)
                rootView.addView(view, FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                ))

                hideSystemUI()
            }

            override fun onHideCustomView() {
                if (customView == null) return

                webView.visibility = View.VISIBLE
                val rootView = findViewById<FrameLayout>(android.R.id.content)
                rootView.removeView(customView)
                customView = null
                customViewCallback?.onCustomViewHidden()
                customViewCallback = null

                showSystemUI()
            }
        }

        val webSettings = webView.settings
        webSettings.javaScriptEnabled = true
        webSettings.domStorageEnabled = true
        webSettings.mediaPlaybackRequiresUserGesture = false
        webSettings.useWideViewPort = true

        val savedUrl = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            .getString(KEY_SERVER_URL, DEFAULT_URL)!!
        webView.loadUrl(savedUrl)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (customView != null) {
                    (webView.webChromeClient as? WebChromeClient)?.onHideCustomView()
                } else if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    finish()
                }
            }
        })
    }

    // --- THIS DETECTS THE ROTATION ---
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)

        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            // Phone rotated to landscape: tell the JS player to click its fullscreen button
            webView.evaluateJavascript("document.querySelector('.lyt_btn_fullscreen')?.click();", null)
        } else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT) {
            // Phone rotated to portrait: if we are in fullscreen, force exit
            if (customView != null) {
                (webView.webChromeClient as? WebChromeClient)?.onHideCustomView()
            }
        }
    }

    private fun hideSystemUI() {
        window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        or View.SYSTEM_UI_FLAG_FULLSCREEN
                )
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
    }

    private fun showSystemUI() {
        window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                )
        window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), NOTIFICATION_PERMISSION_CODE)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        val intent = Intent(this, AudioService::class.java).apply { action = AudioService.ACTION_APP_VISIBLE }
        startService(intent)

        webView.onResume()
        webView.resumeTimers()
        handler.postDelayed(showDialogRunnable, 10000)
    }

    override fun onPause() {
        super.onPause()
        val intent = Intent(this, AudioService::class.java).apply { action = AudioService.ACTION_APP_HIDDEN }
        startService(intent)
        handler.removeCallbacks(showDialogRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing) {
            val intent = Intent(this, AudioService::class.java).apply { action = AudioService.ACTION_STOP }
            startService(intent)
        }
    }

    private val showDialogRunnable = Runnable {
        if (!isUrlDialogShowing && progressBar.visibility == FrameLayout.VISIBLE) {
            showUrlDialog()
        }
    }

    @JavascriptInterface
    fun checkPageContent(pageText: String) {
        if (pageText.trim().contains("502 Bad Gateway", ignoreCase = true)) {
            handler.post {
                if (!isUrlDialogShowing) {
                    showUrlDialog()
                }
            }
        } else {
            handler.removeCallbacks(showDialogRunnable)
            progressBar.visibility = FrameLayout.GONE
        }
    }

    private fun showUrlDialog() {
        if (isUrlDialogShowing) return
        isUrlDialogShowing = true
        handler.removeCallbacks(showDialogRunnable)

        val editText = EditText(this).apply {
            hint = "https://your-new-link.trycloudflare.com"
            val currentUrl = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                .getString(KEY_SERVER_URL, DEFAULT_URL)
            setText(currentUrl)
            setSelection(text.length)
        }

        AlertDialog.Builder(this)
            .setTitle("Connect to LocalYT")
            .setMessage("The current URL is unreachable or returned a 502 error. Enter the URL to connect to your LocalYT server:")
            .setView(editText)
            .setPositiveButton("Connect") { _, _ ->
                var newUrl = editText.text.toString().trim()

                if (newUrl.isNotEmpty() && !newUrl.startsWith("http://") && !newUrl.startsWith("https://")) {
                    newUrl = "https://$newUrl"
                }

                if (newUrl.isNotEmpty()) {
                    getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                        .edit()
                        .putString(KEY_SERVER_URL, newUrl)
                        .apply()

                    isUrlDialogShowing = false
                    progressBar.visibility = FrameLayout.VISIBLE
                    webView.loadUrl(newUrl)
                } else {
                    isUrlDialogShowing = false
                    showUrlDialog()
                }
            }
            .setNegativeButton("Cancel") { dialog, _ ->
                isUrlDialogShowing = false
                dialog.cancel()
            }
            .setCancelable(false)
            .show()
    }
}