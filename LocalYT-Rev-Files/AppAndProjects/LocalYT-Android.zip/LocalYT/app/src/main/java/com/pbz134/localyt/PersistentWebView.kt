package com.pbz134.localyt

import android.content.Context
import android.util.AttributeSet
import android.webkit.WebView

class PersistentWebView(context: Context, attrs: AttributeSet) : WebView(context, attrs) {

    companion object {
        // A static reference to our WebView so the Service can access it
        var instance: PersistentWebView? = null
    }

    init {
        instance = this
    }

    override fun onDetachedFromWindow() {
        // Do NOT call super.onDetachedFromWindow() here. 
        // This prevents Android from destroying the WebView when the Activity closes.
    }

    // We will call this manually from the Service when it's time to truly destroy it
    fun fullyDestroy() {
        super.onDetachedFromWindow()
        destroy()
        instance = null
    }
}