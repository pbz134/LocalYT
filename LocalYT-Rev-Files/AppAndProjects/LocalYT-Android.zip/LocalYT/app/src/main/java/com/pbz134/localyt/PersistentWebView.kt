package com.pbz134.localyt

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.webkit.WebView

class PersistentWebView(context: Context, attrs: AttributeSet) : WebView(context, attrs) {

    companion object {
        var instance: PersistentWebView? = null
    }

    init {
        instance = this
    }

    override fun onDetachedFromWindow() {
        // Do NOT call super.onDetachedFromWindow() here. 
        // This prevents Android from destroying the WebView when the Activity closes.
    }

    // CRITICAL: Trick the WebView into thinking it is always visible to the user.
    // This prevents the Chromium backend from suspending the media pipeline.
    override fun onWindowVisibilityChanged(visibility: Int) {
        if (visibility == View.VISIBLE) {
            super.onWindowVisibilityChanged(visibility)
        } else {
            // Lie to the WebView: Tell it the window is still visible even if the app is minimized
            super.onWindowVisibilityChanged(View.VISIBLE)
        }
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, View.VISIBLE)
    }

    // We will call this manually from the Service when it's time to truly destroy it
    fun fullyDestroy() {
        super.onDetachedFromWindow()
        destroy()
        instance = null
    }
}